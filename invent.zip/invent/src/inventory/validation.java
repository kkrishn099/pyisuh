package inventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class validation {

public boolean validify(String name,String password){
	Connection con=new connectionmanager().getconnection();
	String sql="Select * from MEMBER Where users='"+name.toString()+"' And Password='"+password.toString()+"'";
	try {System.out.println("hello "+name+"   " +password);
//PreparedStatement ps=con.prepareStatement(sql);
//ps.setString(1,name);
//ps.setString(2,password);
Statement ps=con.createStatement();

	ResultSet rs=ps.executeQuery(sql);		
System.out.println("here2");


		if(rs.next()){
			System.out.println("here");
			rs.close();
			con.close();
			
			return true;
		}
		else{
			System.out.println("idhar aara hai bhai	");
			return  false;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
	}
	
return false;
}
}
