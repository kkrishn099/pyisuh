package inventory;

import java.io.InputStream;
import java.sql.Blob;

public class invBean {
int productID;
String Product_name;
int quatity;
double  price;
InputStream file=null;
public InputStream getFile() {
	return file;
}
public void setFile(InputStream file) {
	this.file = file;
}
public int getProductID() {
	return productID;
}
public void setProductID(int productID) {
	this.productID = productID;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public int getQuatity() {
	return quatity;
}
public void setQuatity(int quatity) {
	this.quatity = quatity;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}


}
