package inventory;

public interface Type {
String home="mLogin";
String inventory="inventory";
String Add="AddProduct";
String Search="Search";
}
