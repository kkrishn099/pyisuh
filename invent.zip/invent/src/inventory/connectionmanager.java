package inventory;


import java.sql.Connection;
import java.sql.DriverManager;

public class connectionmanager {
 Connection con=null;
 public Connection getconnection()
{
	 try{
	

	 Class.forName("oracle.jdbc.driver.OracleDriver");
	 con=DriverManager.getConnection("jdbc:oracle:thin:@172.21.18.31:1521:xe","cata","cata");
		
	 
	 
	 
	 }
	 catch (Exception e) {
 System.out.println(e);	
 }
return con;
}
}
