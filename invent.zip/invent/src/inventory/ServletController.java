package inventory;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ServletController
 */
@WebServlet("/ServletController")
@MultipartConfig(maxFileSize = 16177215)
public class ServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	String type=request.getParameter("type");
	if(Type.home.equals(type)){
		if(new validation().validify(request.getParameter("user"),request.getParameter("pass"))){
			request.getRequestDispatcher("inventory.html").forward(request, response);
			
		}
		else{
response.sendRedirect("home.html");
		}
		
	if(Type.Add.equals(type)){
		invBean bean=new invBean();
bean.setProduct_name(request.getParameter("pname"));
bean.setProductID(Integer.parseInt(request.getParameter("Id")));
bean.setPrice(Double.parseDouble(request.getParameter("Price")));
bean.setQuatity(Integer.parseInt(request.getParameter("Quantity")));
InputStream inputStream = null;
	Part file =request.getPart("img");
	if(file!=null){
		System.out.println(file.getName());
      System.out.println(file.getSize());
      System.out.println(file.getContentType());
		}
	inputStream=file.getInputStream();	
	bean.setFile(inputStream);
	HttpSession session=request.getSession();
	session.setAttribute("beanobj",bean);
	request.getRequestDispatcher("insert").forward(request, response);

	
	}
		
	}
	
	
	
	
	}

}
